utilsRelativePath = "./utils"
welcomeJsonFileRelativePath = "./utils/welcome.json"

#########################  Mongo Config Details  ###############################
mongoUri = "mongodb+srv://inventory-admin:inventory123@inventory.rbcanbq.mongodb.net/test?authSource=admin&replicaSet=atlas-13oxx1-shard-0&readPreference=primary&ssl=true"
mongoInventoryDb = "inventory"
mongoUserCollection = "raado-users"
mongoTransactionCollection = "raado-transactions"
######################### common Collection SDK ################################
id = "_id"
######################### raado-transaction Collection SDK #####################
tnxCollectionTimeOfTransaction = "timeOfTransaction"
tnxCollectionFromProcess = "fromProcess"
tnxCollectionToProcess = "toProcess"
tnxCollectionFromUserId = "fromUserId"
tnxCollectionToUserId = "toUserId"
tnxCollectionFromProcess = "fromProcess"
tnxCollectionFromUserWage="fromUserWage"
tnxCollectionFromUserName = "fromUserName"
txnCollectionStatus="status"

######################### raado-user Collection SDK #####################
userCollectionUserId = "userId"
userCollectionUserName="name"
######################### API Input Parameter #####################
userIdParameter = "userId"
startDateParameter = "startDate"
endDateParameter = "endDate"
processIdParameter = "processId"

######################### Data base constants #####################
DataBaseStatusApproved="APPROVED"